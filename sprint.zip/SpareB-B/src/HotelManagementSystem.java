import java.time.LocalDate;

// Main class for the Hotel Management System

public class HotelManagementSystem
{

    public static void main(String[] args)
    {
        System.out.println("=== Welcome to Hotel Management System ===");
        System.out.println();

        // 1. Create some facilities
        System.out.println("1. Creating Facilities...");
        Facility wifi = new Facility("WiFi", "High-speed internet access", true, 10.0, "24/7");
        Facility breakfast = new Facility("Breakfast", "Continental breakfast", true, 15.0, "6:00-10:00");
        Facility parking = new Facility("Parking", "Secure parking space", true, 20.0, "24/7");
        Facility gym = new Facility("Gym", "Fully equipped fitness center", true, 25.0, "5:00-23:00");
        Facility pool = new Facility("Pool", "Heated outdoor swimming pool", true, 30.0, "7:00-21:00");
        Facility spa = new Facility("Spa", "Luxury spa and wellness center", true, 50.0, "9:00-20:00");
        Facility businessCenter = new Facility("Business Center", "Computers, printers, and meeting spaces", true, 15.0, "24/7");
        Facility laundry = new Facility("Laundry", "Laundry and dry cleaning services", true, 12.0, "8:00-20:00");

        // 2. Create accommodations
        System.out.println("2. Creating Accommodations...");

        // Standard Rooms
        Room room101 = new Room("101", "Standard Room", "First Floor", true, 100.0,
                "Double", true, false, 1, "Double", false, true);
        Room room102 = new Room("102", "Deluxe Room", "First Floor", true, 150.0,
                "Queen", true, true, 1, "Queen", true, true);
        Room room103 = new Room("103", "Superior Room", "Third Floor", false, 200.0,
                "Single", true, false, 1, "Single", true, true);
        Room room108 = new Room("108", "City View Room", "Fourth Floor", true, 220.0,
                "King", true, true, 1, "King", true, true);

        // Suites
        Suite suite201 = new Suite("201", "Executive Suite", "Second Floor", true, 300.0,
                1, 1, true, true, true, "Executive");
        Suite suite202 = new Suite("202", "Presidential Suite", "Penthouse Floor", true, 800.0,
                2, 2, true, true, true, "Presidential");
        Suite suite206 = new Suite("206", "Royal Suite", "Penthouse Floor", true, 1200.0,
                3, 2, true, true, true, "Royal");
        Suite suite203 = new Suite("203", "Honeymoon Suite", "Third Floor", false, 450.0,
                1, 1, true, true, true, "Luxury");

        // Event Spaces
        EventSpace eventSpace01 = new EventSpace("01", "The Prospect Hall", "Ground Floor", false, 2000.0,
                80, 40, "Marriage", true, true, true, true, 2, true);
        EventSpace eventSpace02 = new EventSpace("02", "Grand Ballroom", "Ground Floor", true, 3500.0,
                200, 100, "Corporate", true, true, true, true, 3, true);
        EventSpace eventSpace05 = new EventSpace("05", "Garden Pavilion", "Outdoor", true, 1500.0,
                60, 30, "Wedding", true, false, true, true, 2, false);
        EventSpace eventSpace07 = new EventSpace("07", "The Terrace", "Rooftop", false, 1800.0,
                50, 25, "Reception", true, false, true, true, 1, false);

        // 3. Add facilities to accommodations
        System.out.println("3. Adding Facilities to Rooms...");
        room101.addFacility(wifi);
        room101.addFacility(breakfast);

        room102.addFacility(wifi);
        room102.addFacility(breakfast);
        room102.addFacility(parking);

        suite201.addFacility(wifi);
        suite201.addFacility(breakfast);
        suite201.addFacility(parking);
        suite201.addFacility(spa);

        suite202.addFacility(wifi);
        suite202.addFacility(breakfast);
        suite202.addFacility(parking);
        suite202.addFacility(spa);
        suite202.addFacility(gym);
        suite202.addFacility(pool);

        eventSpace01.addFacility(wifi);
        eventSpace01.addFacility(businessCenter);
        eventSpace01.addFacility(parking);

        eventSpace02.addFacility(wifi);
        eventSpace02.addFacility(businessCenter);
        eventSpace02.addFacility(parking);
        eventSpace02.addFacility(laundry);

        // 4. Create guests
        System.out.println("4. Creating Guests...");
        Address address1 = new Address("123 Main St", "London", "England", "SW1A 1AA", "UK");
        Address address2 = new Address("456 Oak Ave", "Manchester", "England", "M1 1AB", "UK");
        Address address3 = new Address("789 Pine Rd", "Birmingham", "England", "B1 1TT", "UK");
        Address address4 = new Address("321 Elm St", "Liverpool", "England", "L1 0RN", "UK");
        Address address5 = new Address("654 Maple Dr", "Glasgow", "Scotland", "G1 1AA", "UK");

        Guest guest1 = new Guest("G001", "John Smith", "john.smith@email.com", "555-0101",
                address1, LocalDate.now());
        Guest guest2 = new Guest("G002", "Sarah Johnson", "sarah.j@email.com", "555-0102",
                address2, LocalDate.now().minusDays(30));
        Guest guest3 = new Guest("G003", "Michael Brown", "m.brown@email.com", "555-0103",
                address3, LocalDate.now().minusDays(15));
        Guest guest4 = new Guest("G004", "Emily Davis", "emily.davis@email.com", "555-0104",
                address4, LocalDate.now().minusDays(7));
        Guest guest5 = new Guest("G005", "Robert Wilson", "r.wilson@email.com", "555-0105",
                address5, LocalDate.now().minusDays(45));

        // 5. Create Bookings
        System.out.println("5. Creating Bookings...");
        LocalDate checkIn1 = LocalDate.now().plusDays(7);
        LocalDate checkOut1 = LocalDate.now().plusDays(10);
        Booking booking1 = new Booking("B001", guest1, room101, checkIn1, checkOut1, 2);

        LocalDate checkIn2 = LocalDate.now().plusDays(3);
        LocalDate checkOut2 = LocalDate.now().plusDays(5);
        Booking booking2 = new Booking("B002", guest2, suite201, checkIn2, checkOut2, 2);

        LocalDate checkIn3 = LocalDate.now().plusDays(14);
        LocalDate checkOut3 = LocalDate.now().plusDays(15); // One day event
        Booking booking3 = new Booking("B003", guest3, eventSpace02, checkIn3, checkOut3, 100);

        // 6. Create Special Requests
        System.out.println("6. Creating Special Requests...");
        SpecialRequest request1 = new SpecialRequest("SR001", "Food", "Vegetarian meals required");
        request1.setAdditionalCost(15.0);
        request1.approveRequest();

        SpecialRequest request2 = new SpecialRequest("SR002", "Service", "Late checkout at 2 PM");
        request2.setAdditionalCost(25.0);
        request2.approveRequest();

        SpecialRequest request3 = new SpecialRequest("SR003", "Event", "Additional microphone and speakers");
        request3.setAdditionalCost(50.0);
        request3.approveRequest();

        // 7. Create Payments
        System.out.println("7. Creating Payments...");
        Payment payment1 = new Payment("P001", booking1.calculateTotalPrice(), "CREDIT_CARD");
        payment1.processPayment();

        Payment payment2 = new Payment("P002", booking2.calculateTotalPrice(), "DEBIT_CARD");
        payment2.processPayment();

        Payment payment3 = new Payment("P003", booking3.calculateTotalPrice(), "CREDIT_CARD");
        payment3.processPayment();

        // 8. Create Reviews
        System.out.println("8. Creating Reviews...");
        Review review1 = new Review("Excellent Stay!", "The room was clean and staff was very helpful.",
                LocalDate.now().minusDays(5), true);
        Review review2 = new Review("Perfect Wedding Venue", "The event space was beautiful and the staff made our day special.",
                LocalDate.now().minusDays(10), true);
        Review review3 = new Review("Good but could be better", "The suite was nice but the WiFi was slow.",
                LocalDate.now().minusDays(2), true);

        // 9. Display all information
        System.out.println();
        System.out.println("=== SYSTEM OVERVIEW ===");

        System.out.println("\n--- ACCOMMODATIONS ---");
        System.out.println("=== ROOMS ===");
        room101.printDetails();
        System.out.println();
        room102.printDetails();
        System.out.println();
        room108.printDetails();
        System.out.println();

        System.out.println("=== SUITES ===");
        suite201.printDetails();
        System.out.println();
        suite202.printDetails();
        System.out.println();
        suite206.printDetails();
        System.out.println();

        System.out.println("=== EVENT SPACES ===");
        eventSpace01.printDetails();
        System.out.println();
        eventSpace02.printDetails();
        System.out.println();
        eventSpace05.printDetails();

        System.out.println("\n--- GUESTS ---");
        guest1.printDetails();
        System.out.println();
        guest2.printDetails();
        System.out.println();
        guest5.printDetails();

        System.out.println("\n--- BOOKINGS ---");
        booking1.printBookingDetails();
        System.out.println();
        booking2.printBookingDetails();
        System.out.println();
        booking3.printBookingDetails();

        System.out.println("\n--- SPECIAL REQUESTS ---");
        System.out.println("Request 1: " + request1.getDescription() + " | Status: " + request1.getStatus() + " | Cost: £" + request1.getAdditionalCost());
        System.out.println("Request 2: " + request2.getDescription() + " | Status: " + request2.getStatus() + " | Cost: £" + request2.getAdditionalCost());
        System.out.println("Request 3: " + request3.getDescription() + " | Status: " + request3.getStatus() + " | Cost: £" + request3.getAdditionalCost());

        System.out.println("\n--- PAYMENTS ---");
        System.out.println("Payment 1: " + payment1.getPaymentDetails());
        System.out.println("Payment 2: " + payment2.getPaymentDetails());
        System.out.println("Payment 3: " + payment3.getPaymentDetails());

        System.out.println("\n--- REVIEWS ---");
        review1.printDetails();
        System.out.println();
        review2.printDetails();
        System.out.println();
        review3.printDetails();

        System.out.println("\n--- FACILITIES ---");
        System.out.println("WiFi: £" + wifi.getAdditionalCost() + " - " + wifi.getDescription());
        System.out.println("Breakfast: £" + breakfast.getAdditionalCost() + " - " + breakfast.getDescription());
        System.out.println("Parking: £" + parking.getAdditionalCost() + " - " + parking.getDescription());
        System.out.println("Gym: £" + gym.getAdditionalCost() + " - " + gym.getDescription());
        System.out.println("Pool: £" + pool.getAdditionalCost() + " - " + pool.getDescription());
        System.out.println("Spa: £" + spa.getAdditionalCost() + " - " + spa.getDescription());
        System.out.println("Business Center: £" + businessCenter.getAdditionalCost() + " - " + businessCenter.getDescription());
        System.out.println("Laundry: £" + laundry.getAdditionalCost() + " - " + laundry.getDescription());

        // 10. Test some functionality
        System.out.println();
        System.out.println("=== TESTING FUNCTIONALITY ===");

        // Test price calculation
        System.out.println("\n=== PRICING INFORMATION ===");
        System.out.println("Room 101 Base Price: £" + room101.getBasePricePerNight());
        System.out.println("Suite 201 Base Price: £" + suite201.getBasePricePerNight());
        System.out.println("EventSpace 02 Base Price: £" + eventSpace02.getBasePricePerNight());

        // Test booking calculations
        System.out.println("\n=== BOOKING CALCULATIONS ===");
        System.out.println("Booking 1 Total: £" + booking1.calculateTotalPrice());
        System.out.println("Booking 2 Total: £" + booking2.calculateTotalPrice());
        System.out.println("Booking 3 Total: £" + booking3.calculateTotalPrice());

        // Test room availability
        System.out.println("\n=== AVAILABILITY STATUS ===");
        System.out.println("Room 101 Available: " + room101.isAvailable());
        System.out.println("Room 103 Available: " + room103.isAvailable());
        System.out.println("Suite 201 Available: " + suite201.isAvailable());
        System.out.println("Suite 203 (Honeymoon) Available: " + suite203.isAvailable());
        System.out.println("EventSpace 01 Available: " + eventSpace01.isAvailable());
        System.out.println("EventSpace 07 (Terrace) Available: " + eventSpace07.isAvailable());

        // Test payment status
        System.out.println("\n=== PAYMENT STATUS ===");
        System.out.println("Payment 1 Status: " + payment1.getStatus());
        System.out.println("Payment 2 Status: " + payment2.getStatus());
        System.out.println("Payment 3 Status: " + payment3.getStatus());

        // Test refund functionality
        System.out.println("\n=== REFUND TEST ===");
        if (payment1.isRefundable()) {
            System.out.println("Payment 1 is refundable");
            payment1.refundPayment(100.0);
            System.out.println("After refund - Payment 1 Status: " + payment1.getStatus());
        }

        // Display summary statistics
        System.out.println("\n=== HOTEL SUMMARY ===");
        System.out.println("Total Rooms: 4");
        System.out.println("Total Suites: 4");
        System.out.println("Total Event Spaces: 4");
        System.out.println("Total Guests: 5");
        System.out.println("Total Bookings: 3");
        System.out.println("Total Payments: 3");
        System.out.println("Total Reviews: 3");
        System.out.println("Total Special Requests: 3");

        System.out.println();
        System.out.println("=== Hotel Management System Demo Complete ===");
    }
}